package com.example.aquasmart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.example.aquasmart.databinding.ActivityPostLoginBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class PostLogin : AppCompatActivity() {
    private var progre = 0
    private lateinit var binding: ActivityPostLoginBinding
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getPlanta()
    }

    private fun getPlanta() {
        database = FirebaseDatabase.getInstance().getReference("datos/humedad")
        val humedadplant = database.child("Humedad")
        val textViewHumedad = findViewById<TextView>(R.id.tvPorcentaje)

        humedadplant.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val humedad = snapshot.getValue(Int::class.java)

                textViewHumedad.text = humedad.toString()
            }
            override fun onCancelled(error: DatabaseError) {
                // Muestra un mensaje de error al usuario
                Toast.makeText(applicationContext, "Error al leer los datos: ${error.code} ${error.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}