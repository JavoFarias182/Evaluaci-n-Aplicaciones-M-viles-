package com.example.aquasmart

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aquasmart.databinding.ActivityLoginBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class Login : AppCompatActivity() {

    //Agregar ViewBinding
    private lateinit var binding: ActivityLoginBinding
    //Importar firebase Auth
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Inicializar Firebase Auth
        auth = Firebase.auth

        //Reconocer boton login
        binding.btnInLogin.setOnClickListener {
            //Obtener el correo y la contraseña
            val email = binding.etCorreo.text.toString()
            val password = binding.etPassword.text.toString()

            //Validar si los campos cuentan con datos
            if(email.isEmpty()){
                binding.etCorreo.error = "Ingrese un correo porfavor"
                return@setOnClickListener
            }
            if(password.isEmpty()) {
                binding.etPassword.error = "Ingrese una contraseña porfavor"
                return@setOnClickListener
            }
            SignIn(email, password)
        }
    }

    private fun SignIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Toast.makeText(this, "Inicio Correcto", Toast.LENGTH_LONG).show()
                val intent = Intent(this, PostLogin::class.java)
                startActivity(intent)
            }
            else {
                Toast.makeText(this, "ERROR", Toast.LENGTH_LONG).show()
            }
        }
    }
}