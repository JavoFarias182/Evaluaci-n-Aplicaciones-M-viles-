package com.example.aquasmart

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aquasmart.databinding.ActivityRegistroBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class Registro : AppCompatActivity() {

    //Activar ViewBinding
    private lateinit var binding: ActivityRegistroBinding

    //Firebase auth
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Activar el auth de firebase
        auth = Firebase.auth

        //Boton Registrar
        binding.btnRegistro.setOnClickListener {

            //Obtener los datos de los campos
            val email:String = binding.etCorreo.text.toString()
            val password:String = binding.etPassword.text.toString()
            val repassword:String = binding.etPassword2.text.toString()

            //Valdidar si los campos estan vacios
            if (email.isEmpty()) {
                binding.etCorreo.error = "Ingrese un correo porfavor"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                binding.etPassword.error = "Ingrese una contraseña porfavor"
                return@setOnClickListener
            }
            if (repassword.isEmpty()) {
                binding.etPassword2.error = "Debe confirmar la contraseña"
                return@setOnClickListener
            }
            if(password != repassword) {
                binding.etPassword2.error = "Las contraseñas deben coincidir"
                return@setOnClickListener
            }

            if (password == repassword) {
                registrarUsuario(email, password)
            }
        }
    }

    private fun registrarUsuario(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener {
            if (it.isSuccessful) {
                Toast.makeText(this, "Usuario correctamente registrado", Toast.LENGTH_LONG).show()
                val intent = Intent(this, Login::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "ERROR", Toast.LENGTH_LONG).show()
            }
        }
    }
}